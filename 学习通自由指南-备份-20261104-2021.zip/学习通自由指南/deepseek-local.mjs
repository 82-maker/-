import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';
import { requestAnswers } from './deepseek-request.mjs';
import { readWindowsApiKey } from './deepseek-key-input.mjs';
import { validateApiKey } from './deepseek-auth.mjs';

const PORT = 37841;
// 页面脚本每次启动都会来 /session 取令牌，所以不再把令牌写进脚本文件。
const token = randomBytes(24).toString('hex');
// 页面也可以直接来取脚本本身：1600 多行靠剪贴板搬容易坏，粘一行 loader 更稳。
const scriptPath = fileURLToPath(new URL('./xuexitong-console.js', import.meta.url));
const allowedOrigin = (origin) => /^https:\/\/([a-z0-9-]+\.)*chaoxing\.com$/i.test(origin || '');

// 图形输入窗口一旦确认不可用，本次运行就不再反复尝试，直接用控制台输入。
let keyWindowUnavailable = false;

async function readApiKey() {
    if (process.platform === 'win32' && !keyWindowUnavailable) {
        console.log('请在弹出的“输入 DeepSeek 密钥”窗口里粘贴密钥并确认。');
        try {
            return await readWindowsApiKey();
        } catch (error) {
            if (error.code !== 'KEY_WINDOW_UNAVAILABLE') throw error;
            keyWindowUnavailable = true;
            console.warn(`密钥输入窗口不可用：${error.message}`);
            console.warn('改用这个黑色窗口输入：粘贴密钥后按 Enter。');
        }
    }
    if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
        const rl = createInterface({ input: process.stdin, output: process.stdout });
        const value = await rl.question('DeepSeek API Key: ');
        rl.close();
        return value.trim();
    }
    process.stdout.write('请粘贴 DeepSeek API Key 后按 Enter（输入不显示）：');
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    return new Promise((resolve, reject) => {
        let value = '';
        const onData = (chunk) => {
            for (const char of chunk) {
                if (char === '\r' || char === '\n') {
                    process.stdin.off('data', onData);
                    process.stdin.setRawMode(false);
                    process.stdout.write('\n');
                    resolve(value.trim());
                    return;
                }
                if (char === '\u0003') {
                    process.stdin.off('data', onData);
                    process.stdin.setRawMode(false);
                    reject(new Error('已取消'));
                    return;
                }
                if (char === '\u007f' || char === '\b') value = value.slice(0, -1);
                else value += char;
            }
        };
        process.stdin.on('data', onData);
    });
}

let apiKey;
while (!apiKey) {
    try {
        const candidate = await readApiKey();
        if (!candidate) {
            console.log('还没有收到密钥，请重新输入。');
            continue;
        }
        console.log('已收到密钥，正在向 DeepSeek 检查，请稍等……');
        const result = await validateApiKey(candidate);
        if (!result.available) {
            throw new Error('密钥已验证，但账户可用余额不足。请在 DeepSeek 官方平台检查额度后重新启动。');
        }
        apiKey = candidate;
        console.log('密钥验证通过，账户有可用额度。');
    } catch (error) {
        console.error(error.message);
        if (error.code === 'INVALID_API_KEY') {
            console.log('输入窗口会重新打开，请粘贴完整的新密钥。');
            continue;
        }
        process.exit(1);
    }
}
// 页面脚本启动时会自己来 /session 取当前令牌，不再把令牌写进脚本文件，也就不需要检查它。

function send(res, status, data, origin) {
    res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Access-Control-Allow-Origin': origin,
        'Vary': 'Origin',
    });
    res.end(JSON.stringify(data));
}

function validQuestions(questions) {
    if (!Array.isArray(questions) || questions.length < 1 || questions.length > 30) return false;
    return questions.every((q, i) => Number.isInteger(q.id) && q.id === i + 1 &&
        ['单选题', '多选题', '判断题'].includes(q.type) &&
        typeof q.question === 'string' && q.question.length > 0 && q.question.length <= 500 &&
        Array.isArray(q.options) && q.options.length >= 2 && q.options.length <= 8 &&
        new Set(q.options.map((o) => o.letter)).size === q.options.length &&
        q.options.every((o) => /^[A-H]$/.test(o.letter) && typeof o.text === 'string' && o.text.length > 0 && o.text.length <= 500));
}

let busy = false;
const server = createServer(async (req, res) => {
    const origin = req.headers.origin;
    if (!allowedOrigin(origin)) {
        res.writeHead(403, { 'Content-Type': 'text/plain' });
        res.end('Origin not allowed');
        return;
    }
    if (req.method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': origin,
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, X-Xuexitong-Token',
            'Access-Control-Allow-Private-Network': 'true',
            'Access-Control-Max-Age': '600',
            'Vary': 'Origin',
        });
        res.end();
        return;
    }
    // 页面脚本自己来取当前令牌：服务每次启动都会换令牌，以前“先复制脚本、后启动服务”就整轮失效。
    // 能拿到它的前提仍然是 Origin 必须是学习通页面（上面的白名单），别的网站拿不到。
    if (req.method === 'GET' && req.url === '/session') {
        send(res, 200, { token }, origin);
        return;
    }
    // 直接把脚本原文给页面：1600 多行用剪贴板搬容易在途中损坏（控制台报 Invalid or unexpected token）。
    if (req.method === 'GET' && req.url === '/script') {
        try {
            const body = readFileSync(scriptPath, 'utf8');
            res.writeHead(200, {
                'Content-Type': 'text/javascript; charset=utf-8',
                'Cache-Control': 'no-store',
                'Access-Control-Allow-Origin': origin,
                'Vary': 'Origin',
            });
            res.end(body);
        } catch (error) {
            res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('读取 xuexitong-console.js 失败：' + error.message);
        }
        return;
    }
    if (req.headers['x-xuexitong-token'] !== token) {
        send(res, 403, { error: '本地令牌不匹配，页面脚本会自动重新取一次；若仍失败请刷新课程页重跑' }, origin);
        return;
    }
    if (req.method === 'GET' && req.url === '/health') {
        send(res, 200, { ok: true }, origin);
        return;
    }
    if (req.method !== 'POST' || req.url !== '/answer') {
        send(res, 404, { error: '未找到接口' }, origin);
        return;
    }
    if (busy) {
        send(res, 429, { error: '上一批题目仍在处理' }, origin);
        return;
    }
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) {
        send(res, 415, { error: '仅接受 JSON' }, origin);
        return;
    }
    busy = true;
    try {
        let raw = '';
        for await (const chunk of req) {
            raw += chunk.toString('utf8');
            if (raw.length > 100000) throw new Error('请求内容过大');
        }
        const questions = JSON.parse(raw).questions;
        if (!validQuestions(questions)) throw new Error('题目格式不正确');
        const answers = await requestAnswers(questions, apiKey);
        send(res, 200, { answers }, origin);
    } catch (error) {
        send(res, 502, { error: error.message }, origin);
    } finally {
        busy = false;
    }
});

server.listen(PORT, '127.0.0.1', () => {
    console.log(`本地服务已启动：http://127.0.0.1:${PORT}`);
    console.log('请双击“复制网页脚本.cmd”，把脚本粘贴到学习通课程页的控制台并按 Enter。');
    console.log('页面脚本会自己来本地服务取本次启动的连接令牌，服务重启后不用重新复制。');
    console.log('关闭本窗口即可停止服务；API Key 不会写入文件。');
});

