(function xuexitongMain() {
const PAGE = window;
const $ = (...args) => PAGE.jQuery(...args);
const APP_KEY = '__xuexitongConsoleDeepSeek';
const BOOT_TIMER_KEY = '__xuexitongConsoleDeepSeekBootTimer';
const LOCAL_URL = 'http://127.0.0.1:37841';
const TOKEN_PATTERN = /^[0-9a-f]{48}$/;
// 正常情况下由本地服务在启动时写进这里；如果服务重启换过令牌，下面的 connectLocal() 会自己取新的。
let LOCAL_TOKEN = '__LOCAL_TOKEN__';
const startedByKeeper = PAGE.__xuexitongAutoInjected === true;
delete PAGE.__xuexitongAutoInjected;
if (!/^https:\/\/([a-z0-9-]+\.)*chaoxing\.com$/i.test(location.origin) ||
!location.pathname.includes('/mycourse/studentstudy')) {
console.error('请在学习通课程播放页的控制台执行本脚本');
return;
}

// 服务每次启动都会换令牌。以前“先复制脚本、后启动服务”就全废了，现在页面自己问服务要令牌。
async function connectLocal() {
const probe = (token) => fetch(`${LOCAL_URL}/health`, {
headers: { 'X-Xuexitong-Token': token },
signal: AbortSignal.timeout(4000),
});
if (TOKEN_PATTERN.test(LOCAL_TOKEN)) {
try {
const response = await probe(LOCAL_TOKEN);
if (response.ok) return true;
} catch (_) { /* 服务没起来时继续问下面 */ }
}
try {
const response = await fetch(`${LOCAL_URL}/session`, { signal: AbortSignal.timeout(4000) });
if (!response.ok) return false;
const data = await response.json();
const token = String(data?.token || '');
if (!TOKEN_PATTERN.test(token)) return false;
LOCAL_TOKEN = token;
const check = await probe(token);
return check.ok;
} catch (_) {
return false;
}
}

const previousApp = PAGE[APP_KEY];
if (previousApp && typeof previousApp.destroy === 'function') {
previousApp.destroy();
}
if (PAGE.__xuexitongPlayerV3 && typeof PAGE.__xuexitongPlayerV3.destroy === 'function') {
PAGE.__xuexitongPlayerV3.destroy();
}
if (PAGE.__xuexitongPlayerV4DeepSeek && typeof PAGE.__xuexitongPlayerV4DeepSeek.destroy === 'function') {
PAGE.__xuexitongPlayerV4DeepSeek.destroy();
}
if (PAGE[BOOT_TIMER_KEY]) {
clearInterval(PAGE[BOOT_TIMER_KEY]);
PAGE[BOOT_TIMER_KEY] = null;
}
if (!startedByKeeper) installNavigationKeeper();
installHud();
connectLocal().then((connected) => {
if (!connected) {
console.error('DeepSeek 本地服务不可用：请双击 start-local-service.cmd 启动服务，并允许 Edge 访问本地网络。');
return;
}
console.log('DeepSeek 本地服务已连接');
if (typeof PAGE.jQuery === 'undefined') {
const script = document.createElement('script');
script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
script.type = 'text/javascript';
script.onload = function () {
console.log('jQuery loaded.');
waitForCoursePage();
};
script.onerror = () => console.error('jQuery 加载失败，脚本无法启动');
document.head.appendChild(script);
} else {
waitForCoursePage();
}
}).catch((error) => console.error('DeepSeek 本地服务不可用，请先启动服务并检查 Edge 本地网络权限:', error));

// 学习通页面自带反调试：它会在页面里执行 debugger 语句，只要开发者工具开着，整页就会停在那里。
// 所以把关键日志同时画到页面右下角，方便关掉 F12 之后仍然能看到进度。
function installHud() {
try {
if (typeof document === 'undefined' || !document.body || document.getElementById('xt-hud')) return;
const box = document.createElement('div');
box.id = 'xt-hud';
box.style.cssText = [
'position:fixed', 'right:10px', 'bottom:10px', 'z-index:2147483647',
'max-width:44vw', 'max-height:32vh', 'overflow:hidden',
'background:rgba(20,20,20,0.82)', 'color:#d8ffd8', 'border-radius:6px',
'padding:6px 9px', 'font:12px/1.5 Consolas,Menlo,monospace',
'white-space:pre-wrap', 'pointer-events:none', 'text-align:left',
'box-shadow:0 2px 10px rgba(0,0,0,0.35)'
].join(';');
const lines = [];
const noisy = /VM\d{4,}|JQMIGRATE|uParse|Deprecated|Failed to load resource|highlight\.min|jquery|^调用|^已添加/i;
const push = (text) => {
const line = String(text).replace(/%c/g, '').replace(/\s+/g, ' ').trim();
if (!line || line.length > 160 || noisy.test(line)) return;
lines.push(line);
if (lines.length > 8) lines.shift();
box.textContent = lines.join('\n');
};
for (const name of ['log', 'info', 'warn', 'error']) {
const original = console[name].bind(console);
console[name] = (...args) => {
try {
push(args
.filter((arg) => !/^(color|font-|background|padding|margin)/.test(String(arg)))
.map((arg) => (typeof arg === 'string' ? arg : (arg instanceof Error ? arg.message : '')))
.join(' '));
} catch (_) { /* 面板本身出错不影响主流程 */ }
original(...args);
};
}
document.body.appendChild(box);
console.log('进度会显示在页面右下角，可以按 F12 关掉开发者工具，避免被页面反调试冻住');
} catch (_) { /* 面板装不上也不影响脚本 */ }
}

function installNavigationKeeper() {
let keeper;
try {
keeper = PAGE.open('', 'xuexitongConsoleKeeper', 'width=360,height=150');
if (!keeper) throw new Error('浏览器阻止了辅助窗口');
keeper.document.title = '学习通自动任务辅助窗口';
keeper.document.body.innerHTML = '<p style="font:16px sans-serif;padding:12px">学习通自动任务正在运行。请保持此窗口打开；课程页整页跳转后，它会重新启动脚本。</p>';
keeper.__xuexitongSource = `(${xuexitongMain.toString()})();`;
keeper.__xuexitongLastUrl = location.href;
keeper.__xuexitongLastInjectionAt = Date.now();
if (!keeper.__xuexitongKeeperTimer) {
keeper.eval(`window.__xuexitongKeeperTimer = setInterval(function () {
                    try {
                        var page = window.opener;
                        if (!page || page.closed) { clearInterval(window.__xuexitongKeeperTimer); window.close(); return; }
                        if (!/^https:\\/\\/([a-z0-9-]+\\.)*chaoxing\\.com\\/mycourse\\/studentstudy/i.test(page.location.href)) return;
                        if (page.location.href !== window.__xuexitongLastUrl) {
                            window.__xuexitongLastUrl = page.location.href;
                            window.__xuexitongLastInjectionAt = Date.now() - 30000;
                        }
                        if (page.document.readyState !== 'complete' || !page.document.querySelector('#coursetree')) return;
                        if (page.__xuexitongConsoleDeepSeek || page.__xuexitongConsoleDeepSeekBootTimer) return;
                        if (Date.now() - window.__xuexitongLastInjectionAt < 30000) return;
                        window.__xuexitongLastInjectionAt = Date.now();
                        page.__xuexitongAutoInjected = true;
                        page.eval(window.__xuexitongSource);
                    } catch (error) {
                        if (Date.now() - (window.__xuexitongLastErrorAt || 0) > 30000) {
                            window.__xuexitongLastErrorAt = Date.now();
                            window.document.body.textContent = '整页跳转后的自动恢复遇到错误：' + error.message;
                            console.warn('学习通整页跳转后的自动恢复暂不可用:', error);
                        }
                    }
                }, 1000);`);
}
keeper.blur();
PAGE.focus();
console.log('整页跳转辅助窗口已启动；请保持它打开');
} catch (error) {
console.warn('整页跳转后无法自动重新启动脚本；请允许此站点打开弹出窗口，或在新页面重新粘贴脚本。', error);
}
}
function waitForCoursePage() {
let attempts = 0;
const maxAttempts = 20;
PAGE[BOOT_TIMER_KEY] = setInterval(() => {
if ($('#coursetree').length > 0) {
clearInterval(PAGE[BOOT_TIMER_KEY]);
PAGE[BOOT_TIMER_KEY] = null;
initializePlayer();
return;
}
attempts++;
if (attempts >= maxAttempts) {
clearInterval(PAGE[BOOT_TIMER_KEY]);
PAGE[BOOT_TIMER_KEY] = null;
console.error('%c脚本启动超时：未检测到课程目录（#coursetree）。请确认当前处于课程播放页。', 'color:#F44336;font-weight:bold');
}
}, 1000);
}
function catalogRow() {
return document.querySelector('#coursetree .posCatalog_active') || document.querySelector('.posCatalog_active');
}

function rowNumber(row) {
return row?.querySelector('.posCatalog_sbar')?.textContent.trim() || '';
}

function activeCardsFrame() {
const frames = Array.from(document.querySelectorAll('iframe[src*="/knowledge/cards"]'))
.filter((frame) => frame.getClientRects().length && getComputedStyle(frame).visibility !== 'hidden');
if (frames.length < 2) return frames[0];
// 切换时可能暂存上一节课件，只在多个框架并存时按当前目录项消歧。
const id = catalogRow()?.id?.match(/(\d{5,})$/)?.[1] || document.getElementById('curChapterId')?.value;
const matching = id && frames.filter((frame) => {
const url = new URL(frame.contentDocument?.URL || frame.src, location.href);
return ['knowledgeid', 'chapterId'].some((key) => url.searchParams.get(key) === id);
});
if (matching?.length === 1) return matching[0];
// 一个小节有多个任务点时，视频页签和测验页签的课件属于同一章，chapterId 会一样。
// 这时再用页签序号（课件地址里的 num）分一次，分不出来就取最新加载的那个，不再直接返回 null。
const tabs = stepTabs();
const active = activeStepTab();
const index = active ? tabs.findIndex((tab) => tab.el === active.el) : -1;
const numOf = (frame) => {
try { return Number(new URL(frame.contentDocument?.URL || frame.src, location.href).searchParams.get('num')); } catch { return NaN; }
};
if (index >= 0) {
const byNum = frames.filter((frame) => numOf(frame) === index);
if (byNum.length === 1) return byNum[0];
}
const usable = frames.filter((frame) => {
const doc = frame.contentDocument;
return doc?.URL && doc.URL !== 'about:blank' && doc.body;
});
return usable[usable.length - 1] || frames[frames.length - 1] || null;
}

function isReadingStep(title) {
return title === '推荐阅读书目' || title === '知识点简介';
}

function visibleElement(el) {
return Boolean(el && el.isConnected && el.getClientRects().length &&
getComputedStyle(el).visibility !== 'hidden');
}

// 一节里可能有多个任务点（学习目标 / 视频 / 章节测验 / 课后习题），它们只是顶部页签。
// 页签数量和顺序都不固定，所以按“当前页签 + 类型”判断，不再依赖 num=0/1。
function stepTabs() {
const result = [];
const seen = new Set();
for (const el of document.querySelectorAll('.prev_white, [id^="dct"]')) {
if (seen.has(el) || !visibleElement(el)) continue;
const full = String(el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
if (!full || full.length > 24) continue;
seen.add(el);
result.push({ el, full, bare: full.replace(/^[0-9]+[.、．]?\s*/, '') });
}
return result;
}

function tabStepKind(tab) {
if (!tab) return '';
const bare = String(tab.bare || '').replace(/[（(]\d+[)）]/g, '');
if (/测验|习题|作业/.test(bare)) return '章节测验';
if (/视频/.test(bare)) return '视频';
return '';
}

function activeStepTab() {
const tabs = stepTabs();
if (!tabs.length) return null;
const marked = tabs.filter((tab) => /(^|[\s_-])(cur|current|active|selected|on)($|[\s_-])/i.test(tab.el.className || '') ||
tab.el.getAttribute('aria-selected') === 'true');
if (marked.length === 1) return marked[0];
const title = String(document.getElementsByClassName('prev_title')[0]?.title || '').replace(/\s+/g, '');
if (title) {
const byTitle = tabs.filter((tab) => tab.bare && (title.includes(tab.bare) || tab.bare.includes(title)));
if (byTitle.length === 1) return byTitle[0];
}
return null;
}

// 同一小节里排在当前页签后面的测验类任务点。
function nextTaskPointTab() {
const tabs = stepTabs();
if (tabs.length < 2) return null;
const active = activeStepTab();
// stepTabs() 每次返回新的包装对象，只能按 DOM 元素比较。
const start = active ? tabs.findIndex((tab) => tab.el === active.el) : -1;
for (let i = start + 1; i < tabs.length; i++) {
if (tabStepKind(tabs[i]) === '章节测验') return tabs[i];
}
return null;
}

function currentVideoTasks(card, row) {
const doc = card?.contentDocument;
if (!row || !doc?.body || doc.readyState === 'loading' || !doc.URL || doc.URL === 'about:blank') return [];
const requested = new URL(card.src, location.href);
const loaded = new URL(doc.URL);
if (loaded.pathname !== requested.pathname) return [];
// 章节切换时，框架地址有时先更新，正文稍后才换。不能沿用旧视频的绿勾。
const chapterId = (url) => url.searchParams.get('knowledgeid') || url.searchParams.get('chapterId');
const loadedId = chapterId(loaded);
const selectedId = row.id?.match(/(\d{5,})$/)?.[1];
if (chapterId(requested) !== loadedId || requested.searchParams.get('num') !== loaded.searchParams.get('num')) return [];
if (selectedId && loadedId && selectedId !== loadedId) return [];
const shown = (el) => el.getClientRects().length > 0 && doc.defaultView.getComputedStyle(el).visibility !== 'hidden';
const frames = Array.from(doc.querySelectorAll('iframe[src*="/ananas/modules/video/"]')).filter(shown);
if (!frames.length || Array.from(doc.querySelectorAll('iframe[src*="/ananas/modules/work/"]')).some(shown)) return [];
const videoMarks = Array.from(doc.querySelectorAll('.ans-job-icon.ans-job-video')).filter(shown);
const rowDone = Boolean(row.querySelector('.icon_Completed'));
return frames.map((frame) => {
const task = frame.closest('.ans-attach-ct');
const individual = task && frames.filter((other) => task.contains(other)).length === 1;
const marks = individual ? Array.from(task.querySelectorAll('.ans-job-icon')).filter(shown) : [];
const localMarks = marks.length ? marks : (frames.length === 1 && videoMarks.length === 1 ? videoMarks : []);
const labels = localMarks.map((mark) => [mark.getAttribute('aria-label'), mark.title, mark.innerText].filter(Boolean).join(' '));
const incomplete = labels.some((label) => /未完成|待完成/.test(label));
const taskDone = (individual && task.classList.contains('ans-job-finished')) ||
labels.some((label) => /任务点已完成|(?:^|\s)已完成(?:$|\s)/.test(label));
// 整小节已经打勾也能作为凭据；橙色数字或播放进度不能。
return {frame, done: !incomplete && Boolean(taskDone || rowDone)};
});
}

function attachQuizAutomation(app) {
const attemptedQuizzes = new Set();
let quizBusy = false;
let quizRestarts = 0;
let stopped = false;
const originalDestroy = app.destroy.bind(app);
app.destroy = function () {
stopped = true;
originalDestroy();
};

const clean = (value) => String(value || '').replace(/\s+/g, ' ').trim();
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const visible = (el) => Boolean(el && el.isConnected && el.getClientRects().length &&
el.ownerDocument.defaultView.getComputedStyle(el).visibility !== 'hidden');
const kindPattern = /[\[【](单选题|多选题|判断题)[\]】]/;

// 判断题文档是否还挂在当前页面上（沿 iframe 链一路走回顶层窗口）。
// 只看 activeCardsFrame() 会更严格，但一个小节有多个任务点时它可能暂时分不清，造成误判。
function docMounted(doc) {
if (!doc || !doc.defaultView) return false;
let current = doc;
for (let depth = 0; depth < 5; depth++) {
if (current === document) return true;
const frame = current.defaultView?.frameElement;
if (!frame || !frame.isConnected) return false;
current = frame.ownerDocument;
}
return false;
}

function courseDocuments() {
const result = [];
const visit = (doc, depth) => {
if (!doc || depth > 3 || result.includes(doc)) return;
result.push(doc);
const frames = depth === 0 ? [activeCardsFrame()].filter(Boolean) : doc.querySelectorAll('iframe');
for (const frame of frames) {
if (!visible(frame)) continue;
try { visit(frame.contentDocument, depth + 1); } catch (_) { /* cross origin */ }
}
};
visit(document, 0);
return result;
}

function quizCompleted() {
const scoreShown = courseDocuments().some((doc) => {
const text = clean(doc.body?.innerText);
const hasGrade = /本次成绩\s*\d+(?:\.\d+)?\s*分/.test(text);
return hasGrade && (/章节测验\s*已完成/.test(text) || /我的答案\s*[:：]/.test(text));
});
if (scoreShown) return true;
return Boolean(app._isChapterTest() && document.querySelector('.posCatalog_active .icon_Completed'));
}

function optionElements(card) {
const labels = Array.from(card.querySelectorAll('span,div,label,li,p,b,i,strong,a'))
.filter((el) => /^[A-H]$/.test(clean(el.textContent)) &&
!Array.from(el.children).some((child) => /^[A-H]$/.test(clean(child.textContent))));
const found = new Map();
for (const label of labels) {
const letter = clean(label.textContent);
if (found.has(letter)) continue;
let target = label;
for (let n = 0; n < 5; n++) {
const parent = target.parentElement;
if (!parent || parent === card) break;
const otherLetters = Array.from(parent.querySelectorAll('span,div,label,li,p,b,i,strong,a'))
.filter((el) => /^[A-H]$/.test(clean(el.textContent)) && el !== label);
if (otherLetters.some((el) => !el.contains(label) && !label.contains(el))) break;
target = parent;
if (clean(target.innerText).length > 1) break;
}
const text = clean(target.innerText).replace(new RegExp(`^${letter}[.、．]?\\s*`), '');
if (text) found.set(letter, { letter, text, element: target });
}
if (!found.size) {
// 有的判断题只写“对 / 错”，没有 A/B 字母；按顺序映射成 A/B，否则这题会被漏掉。
const pick = (words) => Array.from(card.querySelectorAll('span,div,label,li,p,b,i,strong,a,button'))
.find((el) => visible(el) && words.includes(clean(el.textContent)) &&
!Array.from(el.children).some((child) => words.includes(clean(child.textContent))));
const yes = pick(['对', '正确', '是', '√']);
const no = pick(['错', '错误', '否', '×']);
if (yes && no) {
found.set('A', { letter: 'A', text: clean(yes.textContent), element: yes });
found.set('B', { letter: 'B', text: clean(no.textContent), element: no });
}
}
// 视频弹题常把字母和文字写在一起，例如“A、对”“B. 错”，只认单字母会一条选项都找不到。
const inlinePattern = /^([A-H])(?:[.、．:：)）,，]|\s)\s*(\S.*)$/;
const inlineLabels = Array.from(card.querySelectorAll('span,div,label,li,p,b,i,strong,a'))
.filter((el) => {
const text = clean(el.textContent);
if (!text || text.length > 120 || !inlinePattern.test(text)) return false;
return !Array.from(el.children).some((child) => inlinePattern.test(clean(child.textContent)));
});
for (const el of inlineLabels) {
const match = clean(el.textContent).match(inlinePattern);
if (!match || found.has(match[1])) continue;
found.set(match[1], { letter: match[1], text: match[2].trim(), element: el });
}
return Array.from(found.values()).sort((a, b) => a.letter.localeCompare(b.letter));
}

function extractQuestions() {
const questions = [];
for (const doc of courseDocuments()) {
const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
const seenCards = new Set();
let node;
while ((node = walker.nextNode())) {
const kind = clean(node.textContent).match(kindPattern)?.[1];
if (!kind || !visible(node.parentElement)) continue;
let card = node.parentElement;
let options = [];
for (let depth = 0; card && depth < 9; depth++, card = card.parentElement) {
const cardText = clean(card.innerText);
const kinds = cardText.match(new RegExp(kindPattern.source, 'g')) || [];
if (kinds.length > 1) break;
options = optionElements(card);
if (options.length >= 2 && options.length <= 8) break;
}
if (!card || options.length < 2 || options.length > 8 || seenCards.has(card)) continue;
seenCards.add(card);
const full = card.innerText || '';
const firstOption = full.search(/(?:^|\n)\s*A\s*(?:[.、．]|\S)/);
const title = clean(firstOption >= 0 ? full.slice(0, firstOption) :
(node.parentElement.innerText || full))
.replace(/^\d+\s*/, '').replace(kindPattern, '').trim();
if (!title || title.length > 500 || options.some((option) => !option.text || option.text.length > 500)) continue;
questions.push({ kind, title, options, card, doc });
}
}
return questions;
}

function findButton(doc, label) {
const candidates = Array.from(doc.querySelectorAll('button,a,input[type="button"],input[type="submit"],[role="button"],div,span'))
.filter((el) => visible(el) && clean(el.value || el.innerText) === label);
return candidates.find((el) => /^(BUTTON|A|INPUT)$/.test(el.tagName)) ||
candidates.find((el) => !Array.from(el.children).some((child) => clean(child.innerText) === label)) || null;
}

function findNextButton() {
for (const doc of courseDocuments()) {
const known = doc.querySelector('#prevNextFocusNext, #right1, .nextChapter');
if (visible(known) && clean(known.innerText || known.title).includes('下一节')) return known;
const generic = findButton(doc, '下一节');
if (generic) return generic;
}
return null;
}

function nextStepConfirmation() {
// 只处理“去学习 / 下一节”这一种提示，避免误点提交或其他弹框。
const tip = Array.from(document.querySelectorAll('.jobLimitTip')).find((el) =>
visible(el) && /^当前章节还有任务点未完成[，,]是否去完成[？?]?$/.test(clean(el.innerText).replace(/\s/g, '')));
if (!tip) return null;
const box = tip.closest('.jobFinishTip');
const next = box?.querySelector('.nextChapter');
const learn = box?.querySelector('.popMoveDele');
if (visible(next) && clean(next.innerText) === '下一节' && visible(learn) && clean(learn.innerText) === '去学习') return next;
throw new Error('已看到任务点提示，但未找到弹框里的“下一节”，请手动确认。');
}

async function revealQuizQuestions() {
const docs = courseDocuments();
const submit = docs.map((doc) => findButton(doc, '提交')).find(Boolean);
if (!submit) return;
let scroller = submit.parentElement;
while (scroller && scroller !== submit.ownerDocument.body) {
const style = scroller.ownerDocument.defaultView.getComputedStyle(scroller);
if (/(auto|scroll)/.test(style.overflowY) && scroller.scrollHeight > scroller.clientHeight + 100) break;
scroller = scroller.parentElement;
}
if (!scroller || scroller === submit.ownerDocument.body) {
scroller = submit.ownerDocument.scrollingElement;
}
if (!scroller || scroller.scrollHeight <= scroller.clientHeight + 100) return;
scroller.scrollTop = 0;
await sleep(150);
for (let step = 0; step < 50; step++) {
const bottom = scroller.scrollHeight - scroller.clientHeight;
if (scroller.scrollTop >= bottom - 2) break;
scroller.scrollTop = Math.min(bottom, scroller.scrollTop + Math.max(300, scroller.clientHeight * 0.75));
await sleep(120);
}
}

async function waitForQuizQuestions() {
let submitDoc = null;
for (let attempt = 0; attempt < 240; attempt++) {
if (stopped) throw new Error('脚本已停止');
if (quizCompleted()) return null;
submitDoc = courseDocuments().find((doc) => findButton(doc, '提交'));
if (submitDoc) break;
if (attempt > 0 && attempt % 30 === 0) console.log(`测验提交按钮仍在加载，已等待 ${attempt / 2} 秒`);
await sleep(500);
}
if (!submitDoc) throw new Error('进入章节测验后等待 120 秒，仍未找到“提交”按钮。请检查题目框架是否正常加载');

await revealQuizQuestions();
let previousSignature = '';
let stableCount = 0;
for (let attempt = 0; attempt < 240; attempt++) {
if (stopped) throw new Error('脚本已停止');
if (quizCompleted()) return null;
const questions = extractQuestions();
const countText = clean(submitDoc.body.innerText).match(/题量\s*[:：]\s*(\d+)/);
const expected = countText ? Number(countText[1]) : null;
if (questions.length && (!expected || questions.length === expected)) {
const signature = questions.map((q) => `${q.kind}:${q.title}:${q.options.length}`).join('|');
stableCount = signature === previousSignature ? stableCount + 1 : 0;
previousSignature = signature;
if (stableCount >= 3) return questions;
} else {
stableCount = 0;
previousSignature = '';
}
if (attempt > 0 && attempt % 30 === 0) console.log(`测验题目仍在加载，已等待 ${attempt / 2} 秒；当前识别 ${questions.length} 道`);
await sleep(500);
}
throw new Error('测验框架已打开，但等待 120 秒仍未识别完整题目。可运行 app.inspectQuiz() 查看当前识别结果');
}

async function askDeepSeek(questions) {
const payload = questions.map((q, i) => ({
id: i + 1,
type: q.kind,
question: q.title,
options: q.options.map((o) => ({ letter: o.letter, text: o.text })),
}));
console.log('以下是本次发送给 DeepSeek 的题干和选项：', payload);
const post = async () => fetch(`${LOCAL_URL}/answer`, {
method: 'POST',
headers: { 'Content-Type': 'application/json', 'X-Xuexitong-Token': LOCAL_TOKEN },
body: JSON.stringify({ questions: payload }),
signal: AbortSignal.timeout(900000),
});
let response;
try {
response = await post();
} catch (error) {
throw new Error(`无法连接本地 DeepSeek 服务。请确认启动窗口仍在运行，且 Edge 允许本地网络访问。详情：${error.message}`);
}
if (response.status === 403) {
// 服务在运行途中重启过，令牌变了：自己重新取一次，不用重贴脚本。
console.warn('本地令牌已失效（服务重启过），正在重新获取令牌后重试');
if (await connectLocal()) {
try { response = await post(); } catch (error) {
throw new Error(`无法连接本地 DeepSeek 服务。详情：${error.message}`);
}
}
}
const data = await response.json().catch(() => null);
if (!response.ok) throw new Error(data?.error || `本地 DeepSeek 服务返回 HTTP ${response.status}`);
return data.answers;
}

function validateAnswers(questions, answers) {
if (!Array.isArray(answers) || answers.length !== questions.length) throw new Error('AI 返回的题目数量不匹配');
const result = new Map();
for (const item of answers) {
if (!Number.isInteger(item.id) || result.has(item.id) || !Array.isArray(item.letters))
throw new Error('AI 答案格式错误');
const q = questions[item.id - 1];
if (!q) throw new Error('AI 返回未知题号');
const letters = item.letters.map((letter) => clean(letter).toUpperCase());
if (!letters.length) throw new Error(`第 ${item.id} 题 AI 未给出选项，已停止提交`);
if (new Set(letters).size !== letters.length) throw new Error(`第 ${item.id} 题答案包含重复选项，已停止提交`);
if (q.kind !== '多选题' && letters.length !== 1)
throw new Error(`第 ${item.id} 题是${q.kind}，但 AI 返回了 ${letters.length} 个选项，已停止提交`);
const invalidLetters = letters.filter((letter) => !q.options.some((option) => option.letter === letter));
if (invalidLetters.length)
throw new Error(`第 ${item.id} 题 AI 返回了页面中不存在的选项：${invalidLetters.join('、')}，已停止提交`);
result.set(item.id, letters);
}
return result;
}

async function selectAnswers(questions, answers) {
for (let i = 0; i < questions.length; i++) {
const q = questions[i];
for (const letter of answers.get(i + 1)) {
if (stopped) throw new Error('脚本已停止');
const option = q.options.find((item) => item.letter === letter);
if (!option?.element?.isConnected) throw new Error(`第 ${i + 1} 题选项已变化`);
option.element.scrollIntoView({ block: 'center' });
const before = q.card.outerHTML;
option.element.click();
await sleep(150);
const after = q.card.outerHTML;
const input = option.element.matches('input') ? option.element : option.element.querySelector('input');
const checked = input?.checked || option.element.getAttribute('aria-checked') === 'true';
if (before === after && !checked) throw new Error(`第 ${i + 1} 题 ${letter} 选项未确认选中，已停止提交`);
}
}
}

async function confirmSubmitDialog() {
for (let i = 0; i < 20; i++) {
if (stopped) throw new Error('脚本已停止');
const dialogs = courseDocuments().flatMap((doc) =>
Array.from(doc.querySelectorAll('#popok,[role="dialog"],[role="alertdialog"],.layui-layer-dialog,.el-message-box,.modal')));
const platformButton = dialogs.find((el) => el.id === 'popok' && visible(el));
if (platformButton) {
const message = clean(platformButton.ownerDocument.querySelector('#popcontent')?.innerText);
if (/未作答|请选择|请作答|答完/.test(message) && !/确定提交|确认提交/.test(message))
throw new Error(`平台拒绝提交：${message}`);
console.log(`确认平台提交窗口：${message || '提交'}`);
platformButton.click();
return;
}
const dialog = dialogs.find((el) => el.id !== 'popok' && visible(el) && /提交|交卷/.test(clean(el.innerText)));
if (dialog) {
const confirm = findButton(dialog, '确定') || findButton(dialog, '确认') || findButton(dialog, '提交');
if (!confirm) throw new Error('提交确认窗口未找到确认按钮');
confirm.click();
return;
}
await sleep(250);
}
}

async function submitQuiz(doc) {
if (stopped) throw new Error('脚本已停止');
const submit = findButton(doc, '提交');
if (!submit) throw new Error('未找到测验提交按钮');
submit.scrollIntoView({ block: 'center' });
console.log('选项已选择，点击章节测验的提交按钮');
submit.click();
await confirmSubmitDialog();
console.log('提交已确认，等待学习通生成成绩或任务完成标记；确认后再点击“下一节”');
let elapsedHalfSeconds = 0;
while (!stopped) {
await sleep(500);
elapsedHalfSeconds++;
if (quizCompleted()) return;
if (elapsedHalfSeconds % 30 === 0) console.log(`成绩页仍在加载，已等待 ${elapsedHalfSeconds / 2} 秒`);
}
throw new Error('脚本已停止');
}

async function goToNextStep(target) {
if (stopped) throw new Error('脚本已停止');
const openConfirmation = nextStepConfirmation();
const previousStep = app._currentStepTitle();
const previousRow = catalogRow();
const previousNumber = rowNumber(previousRow);
const catalog = Array.from(document.querySelectorAll('#coursetree .posCatalog_select:not(.firstLayer)'));
const index = catalog.indexOf(previousRow);
// 已打勾的独立阅读页按目录顺序前进，可跨章，并避开旧课件的下一节按钮。
const expectedRow = target?.row || (isReadingStep(previousStep) && previousRow?.querySelector('.icon_Completed') && index >= 0 ? catalog[index + 1] : null);
const expectedNumber = rowNumber(expectedRow);
const next = openConfirmation || target?.button || expectedRow?.querySelector('.posCatalog_name') || findNextButton();
if (!next) throw new Error('未找到页面下方的“下一节”按钮');
app._nextUnitPending = true;
const previousDoc = activeCardsFrame()?.contentDocument;
const previousUrl = previousDoc?.URL;
let confirmed = Boolean(openConfirmation);
app._clearCheckInterval();
app._videoEl = null;
app._isPlaying = false;
next.scrollIntoView({ block: 'center' });
console.log(`${previousStep || '当前学习步骤'}完成，点击页面“下一节”，等待新内容加载`);
next.click();
let currentStep = '';
let stepReady = false;
for (let attempt = 0; attempt < 240; attempt++) {
if (stopped) throw new Error('脚本已停止');
await sleep(500);
if (stopped) throw new Error('脚本已停止');
if (!confirmed) {
const confirm = nextStepConfirmation();
if (confirm) {
confirmed = true;
confirm.click();
console.log('已点击任务点提示框里的“下一节”');
continue;
}
}
currentStep = app._currentStepTitle();
if (target?.quiz && currentStep !== '章节测验') continue;
const currentNumber = rowNumber(catalogRow());
if (expectedNumber && expectedNumber !== currentNumber) continue;
const currentDoc = activeCardsFrame()?.contentDocument;
if (!currentDoc?.body || currentDoc.URL === 'about:blank' || currentDoc.readyState === 'loading') continue;
// 连续两节可以都是阅读或视频，以实际加载的课件区分它们。
const pageChanged = currentDoc !== previousDoc || currentDoc.URL !== previousUrl;
const changed = pageChanged || (currentNumber === previousNumber && currentStep !== previousStep && (!expectedNumber || target?.quiz));
if (changed && (currentStep === '章节测验' || isReadingStep(currentStep))) {
stepReady = true;
break;
}
if (changed && currentStep === '视频') {
app._videoEl = null;
const tasks = currentVideoTasks(activeCardsFrame(), catalogRow());
if ((tasks.length && tasks.every((task) => task.done)) || app._getVideoEl()) {
stepReady = true;
break;
}
}
// 新一节可能停在“学习目标”这类页签上，不算失败：交给 play() 去点“视频”页签。
if (changed && !currentStep) {
stepReady = true;
break;
}
if (attempt > 0 && attempt % 30 === 0) console.log(`下一学习步骤仍在加载，已等待 ${attempt / 2} 秒；当前页签：${currentStep || '未显示'}`);
}
if (!stepReady) {
throw new Error(`点击“下一节”后等待 120 秒，新学习步骤仍未加载完成；当前页签：${currentStep || '未显示'}`);
}
app._nextUnitPending = false;
app._observedNumber = rowNumber(catalogRow());
app._videoEl = null;
app._initCellData();
app.play();
}

app.nextUnit = function (target) {
if (stopped || this._nextUnitPending) return;
this._nextUnitPending = true;
goToNextStep(target).catch((error) => {
this._nextUnitPending = false;
console.error('切换下一学习步骤失败:', error);
});
};

app._skipCompletedVideo = function () {
if (stopped || this._nextUnitPending) return false;
const row = catalogRow();
const tasks = currentVideoTasks(activeCardsFrame(), row);
if (!tasks.length || !tasks.every((task) => task.done)) return false;
const isQuiz = (label) => /^(?:章节测验|课后习题|随堂测验)$/.test(clean(label).replace(/^\d+[.、]?\s*/, ''));
// 优先用当前页签栏里排在视频后面的测验页签；找不到再退回全页搜索。
const tab = nextTaskPointTab()?.el ||
Array.from(document.querySelectorAll('[id^="dct"],.prev_white'))
.find((el) => visible(el) && isQuiz(el.innerText));
const rows = Array.from(document.querySelectorAll('#coursetree .posCatalog_select:not(.firstLayer)'));
const index = rows.indexOf(row);
const nextRow = index >= 0 ? rows[index + 1] : null;
const nextName = nextRow?.querySelector('.posCatalog_name');
let target;
if (tab) target = { button: tab, row, quiz: true };
else if (nextName && isQuiz(nextName.title || (nextName.textContent || '').replace(/^\s*\d+(?:\.\d+)+\s*/, ''))) {
target = { button: nextName, row: nextRow, quiz: true };
}
this._isPlaying = false;
this._clearCheckInterval();
const previouslyPlaying = this._eventVideoEl;
this._detachVideoEvents();
clearTimeout(this._delayedNextUnitTimer);
this._delayedNextUnitTimer = null;
if (previouslyPlaying?.isConnected && !previouslyPlaying.paused) previouslyPlaying.pause();
const video = this._getVideoEl();
if (video && !video.paused) video.pause();
console.log('视频任务已完成，' + (target ? '直接进入测验' : '继续下一学习步骤'));
this.nextUnit(target);
return true;
};

// 视频看到一半会弹出题目（弹题），答完才继续播放。这里复用答题流程处理它。
let popupBusy = false;
const handledPopups = new Set();
const failedPopups = new Set();

function letterLabels(root) {
return Array.from(root.querySelectorAll('span,div,label,li,p,b,i,strong,a'))
.filter((el) => {
if (!visible(el)) return false;
const text = clean(el.textContent);
const single = /^[A-H]$/.test(text);
const inline = text.length <= 120 && /^[A-H](?:[.、．:：)）,，]|\s)\s*\S/.test(text);
if (!single && !inline) return false;
return !Array.from(el.children).some((child) => {
const childText = clean(child.textContent);
return /^[A-H]$/.test(childText) ||
(childText.length <= 120 && /^[A-H](?:[.、．:：)）,，]|\s)\s*\S/.test(childText));
});
});
}

// 弹题的题干和选项可能是兄弟节点，取“仍然只有这几个选项”的最大容器，才能把题干一起带上。
function popupCardFor(letter, doc) {
let card = letter.parentElement;
let best = null;
for (let depth = 0; card && depth < 8 && card !== doc.body; depth++, card = card.parentElement) {
const options = optionElements(card);
if (options.length < 2 || options.length > 6) continue;
const text = clean(card.innerText);
if (text.length > 6 && text.length < 800) best = card;
}
return best;
}

// 兜底：不管选项长什么样，只要页面上出现“判断题/单选题/多选题”和一个可见的“对 / 错”（或“正确 / 错误”）
// 组合，就当成一道判断题。弹题的样式版本实在太多，只靠字母和容器类名认不全。
function fallbackPopupQuestion(doc) {
if (!doc?.body) return null;
const bodyText = clean(doc.body.innerText || '');
if (!/判断题|单选题|多选题/.test(bodyText)) return null;
const pick = (words) => Array.from(doc.querySelectorAll('span,div,label,li,p,b,i,strong,a,em'))
.find((el) => visible(el) && words.includes(clean(el.textContent)) &&
!Array.from(el.children).some((child) => words.includes(clean(child.textContent))));
const yes = pick(['对', '正确', '是', '√']);
const no = pick(['错', '错误', '否', '×']);
if (!yes || !no) return null;
let card = yes.parentElement;
while (card && card !== doc.body && !card.contains(no)) card = card.parentElement;
if (!card || card === doc.body) return null;
const text = clean(card.innerText);
if (text.length < 6 || text.length > 800) return null;
const cut = text.search(/A\s*[、.．:：]?\s*(?:对|正确|是)/);
const title = clean(cut > 0 ? text.slice(0, cut) : text)
.replace(/^\d+\s*/, '').replace(kindPattern, '').replace(/判断题|单选题|多选题/g, '').trim();
if (!title || title.length > 500) return null;
return {
kind: '判断题',
title,
options: [
{ letter: 'A', text: clean(yes.textContent), element: yes },
{ letter: 'B', text: clean(no.textContent), element: no },
],
card,
doc,
};
}

// 页面上看起来挂着题目（但可能没认出来）：用来决定要不要继续抢播放。
function popupLooking() {
for (const doc of courseDocuments()) {
if (!doc.body) continue;
if (!/判断题|单选题|多选题/.test(clean(doc.body.innerText || ''))) continue;
const hasPair = Array.from(doc.querySelectorAll('span,div,label,li,p,b,i,strong,a,em'))
.some((el) => visible(el) && ['对', '错', '正确', '错误'].includes(clean(el.textContent)));
if (hasPair) return true;
}
return false;
}

function detectPopupQuestions() {
const marked = extractQuestions();
if (marked.length) return marked;
const found = [];
for (const doc of courseDocuments()) {
if (!doc.body) continue;
const inFrame = doc !== document;
const confirmable = ['确定', '提交', '确认', '继续', '回答'].some((label) => findButton(doc, label));
const seen = new Set();
for (const letter of letterLabels(doc)) {
const card = popupCardFor(letter, doc);
if (!card || seen.has(card)) continue;
seen.add(card);
const options = optionElements(card);
if (options.length < 2 || options.length > 6) continue;
const full = card.innerText || '';
const firstOption = full.search(/(?:^|\n)\s*A\s*(?:[.、．]|\S)/);
const title = clean(firstOption >= 0 ? full.slice(0, firstOption) : full)
.replace(/^\d+\s*/, '').replace(kindPattern, '').trim();
if (!title || title.length > 500) continue;
if (options.some((option) => !option.text || option.text.length > 500)) continue;
// 弹题一定在课件框架里；顶层页面只在有明显弹层语义时才当成弹题，避免误抓目录里的字母。
// 播放器里的弹题常常没有“确定”按钮（点选项就提交），所以“这个框架里有 video”也算强证据。
const layer = /quiz|popup|dialog|modal|layer|mask/i.test(String(card.className || '') +
' ' + String(card.parentElement?.className || ''));
const inVideo = Boolean(doc.querySelector?.('video'));
if (!layer && !(inFrame && confirmable) && !(inFrame && inVideo)) continue;
const kind = clean(full).match(kindPattern)?.[1] ||
(card.querySelector('input[type="checkbox"]') ? '多选题' : '单选题');
found.push({ kind, title, options, card, doc });
if (found.length >= 3) return found;
}
// 字母/类名这条路走不通时，用“对 / 错”兜底
if (!found.length) {
const fallback = fallbackPopupQuestion(doc);
if (fallback) found.push(fallback);
}
}
return found;
}

app._handleVideoPopup = function () {
if (stopped || this._nextUnitPending) return false;
if (this._currentStepTitle() !== '视频') return false;
if (popupBusy) return true;
let questions;
try { questions = detectPopupQuestions(); } catch (error) { console.warn('弹题识别失败:', error); return false; }
if (!questions.length) return false;
const signature = questions.map((q) => `${q.kind}:${q.title}`).join('|');
if (handledPopups.has(signature) || failedPopups.has(signature)) {
// 已经处理过或已经失败：不要再和弹题抢播放，否则会 play/pause 无限循环。
if (failedPopups.has(signature) && !this._popupStuckShown) {
this._popupStuckShown = true;
console.warn('这道弹题没答上，已停止自动恢复播放：请在页面上点选答案，视频会自己继续。');
}
return true;
}
popupBusy = true;
(async () => {
console.log(`%c检测到视频弹题，共 ${questions.length} 道，正在调用 DeepSeek`, 'color:#FF9800;font-weight:bold');
console.log('弹题内容：', questions.map((q) => ({
type: q.kind, question: q.title, options: q.options.map((o) => `${o.letter}. ${o.text}`),
})));
const answers = validateAnswers(questions, await askDeepSeek(questions));
await selectAnswers(questions, answers);
const doc = questions[0].doc;
const clickConfirm = () => {
// 弹题的“确定”有的在播放器框架里，有的在课件框架里，几层都找一遍。
for (const label of ['确定', '提交', '确认', '继续']) {
for (const target of courseDocuments()) {
const button = findButton(target, label);
if (button) {
console.log('点击弹题按钮：' + clean(button.innerText || button.value));
button.click();
return true;
}
}
}
return false;
};
clickConfirm();
handledPopups.add(signature);
for (let attempt = 0; attempt < 20; attempt++) {
await sleep(500);
if (!detectPopupQuestions().length) break;
if (!clickConfirm()) break;
}
console.log('%c弹题已作答，继续播放视频', 'color:#4CAF50');
this._tryResumePlayback('popup-answered');
})().catch((error) => {
failedPopups.add(signature);
console.error('视频弹题自动作答失败，请手动作答，之后视频会继续:', error);
}).finally(() => { popupBusy = false; });
return true;
};

app.inspectPopup = function () {
const questions = detectPopupQuestions();
return {
found: questions.length,
questions: questions.map((q, i) => ({
id: i + 1, type: q.kind, question: q.title,
options: q.options.map((o) => `${o.letter}. ${o.text}`),
})),
html: questions[0]?.card?.outerHTML?.slice(0, 3000) || '',
};
};

app.inspectQuiz = function () {
return extractQuestions().map((q, i) => ({
id: i + 1, type: q.kind, question: q.title,
options: q.options.map((o) => `${o.letter}. ${o.text}`),
}));
};

let waitingForReading = false;
app._advanceReading = async function (title) {
if (waitingForReading || this._nextUnitPending) return;
waitingForReading = true;
try {
for (let attempt = 0; attempt < 120; attempt++) {
await sleep(500);
if (stopped || this._currentStepTitle() !== title) return;
const doc = activeCardsFrame()?.contentDocument;
// 纯图片的简介也可能已完成，以当前目录的绿勾为准。
if (doc?.readyState === 'complete' && doc.body && doc.URL !== 'about:blank' &&
catalogRow()?.querySelector('.icon_Completed')) {
console.log(title + '已打勾，继续下一节');
this.nextUnit();
return;
}
}
console.log(title + '尚未显示完成，已停留在本页。');
} finally {
waitingForReading = false;
}
};

app._advanceChapterTest = function () {
if (stopped || quizBusy) return;
quizBusy = true;
(async () => {
// 等答案期间测验框架可能自己刷新一次；这种情况重新识别再来，不要整轮作废。
for (let attempt = 0; ; attempt++) {
if (quizCompleted()) {
console.log('检测到当前章节测验已完成，点击“下一节”进入新视频');
await goToNextStep();
return;
}
console.log(attempt ? '重新识别章节测验' : '已进入章节测验，等待题目和提交按钮加载');
const questions = await waitForQuizQuestions();
if (questions === null) {
console.log('检测到当前章节测验已完成，点击“下一节”进入新视频');
await goToNextStep();
return;
}
if (questions.length > 30) throw new Error('题目数量超过 30，已停止自动提交');
const docs = new Set(questions.map((q) => q.doc));
if (docs.size !== 1) throw new Error('题目跨多个框架，已停止自动提交');
const countText = clean(questions[0].doc.body.innerText).match(/题量\s*[:：]\s*(\d+)/);
if (countText && Number(countText[1]) !== questions.length)
throw new Error(`页面显示 ${countText[1]} 道题，脚本只识别 ${questions.length} 道，已停止提交`);
const signature = questions.map((q) => `${q.kind}:${q.title}`).join('|');
if (attemptedQuizzes.has(signature)) throw new Error('本次测验已尝试过，已停止重复提交');
console.log(`识别到 ${questions.length} 道题，正在调用 DeepSeek`);
const answers = validateAnswers(questions, await askDeepSeek(questions));
if (stopped) throw new Error('脚本已停止');
if (!docMounted(questions[0].doc)) {
if (attempt < 2) {
console.warn(`测验页面在等待答案时重新加载了（${attempt + 1}/3），3 秒后重新识别`);
await sleep(3000);
continue;
}
throw new Error('测验页面已经切换，本次作答已停止');
}
console.table(questions.map((q, i) => ({ 题号: i + 1, 题型: q.kind, 选择: answers.get(i + 1).join('') })));
await selectAnswers(questions, answers);
attemptedQuizzes.add(signature);
quizRestarts = 0;
await submitQuiz(questions[0].doc);
console.log('章节测验提交已确认，点击“下一节”进入新视频');
quizBusy = false;
await goToNextStep();
return;
}
})().catch((error) => {
app._nextUnitPending = false;
console.error('章节测验自动作答停止:', error);
// 单次失败不再让整门课停摆：等一会儿重新识别，最多试 3 次（已提交过的不会重复提交）。
if (!stopped && !/已尝试过/.test(error.message) && quizRestarts < 3) {
quizRestarts += 1;
console.warn(`15 秒后重新尝试本章测验（${quizRestarts}/3）`);
setTimeout(() => { if (!stopped) app._advanceChapterTest(); }, 15000);
}
})
.finally(() => { quizBusy = false; });
};

}
function initializePlayer() {
const app = {
configs: {
autoplay: true,
retryInterval: 2000,
maxRetries: 10,
videoCheckInterval: 1000,
guardNoProgressMs: 7000,
guardResumeCooldownMs: 1500,
autoAdvanceNoVideo: false,
},
_videoEl: null,
_treeContainerEl: null,
_isPlaying: false,
_currentRetryCount: 0,
_checkInterval: null,
_eventVideoEl: null,
_boundVideoHandlers: null,
_nextUnitPending: false,
_chapterAdvanceTimes: 0,
_cellData: {
cells: 0,
nCells: 0,
currentCellIndex: 0,
currentNCellIndex: 0,
currentVideoTitle: "",
},
get cellData() {
return this._cellData;
},
run() {
console.log("%c=== 学习通视频与章节测验助手 V4 启动 ===", "color:#4CAF50;font-size:16px;font-weight:bold");
this._nextUnitPending = false;
this._chapterAdvanceTimes = 0;
this._getTreeContainer();
this._initCellData();
console.log(`当前学习步骤：${this._currentStepTitle() || '等待页面加载'}`);
this._videoEl = null;
this._getVideoEl();
this._clearCheckInterval();
this._bindStepNavigation();
this.play();
},
nextUnit() {
if (this._nextUnitPending) {
console.warn('%c已有小节切换正在进行，忽略重复请求', 'color:#FF9800');
return;
}
this._nextUnitPending = true;
this._clearCheckInterval();
console.log("%c=== 准备切换到下一小节 ===", "color:#2196F3;font-size:14px");
try {
const el = this._getTreeContainer();
const cells = el.children("ul").children("li");
const nCells = $(cells.get(this._cellData.currentCellIndex)).find('.posCatalog_select:not(.firstLayer)');
if (nCells.length > this._cellData.currentNCellIndex + 1) {
const nextNIndex = this._cellData.currentNCellIndex + 1;
console.log(`%c切换到同章节下一个视频: ${nextNIndex + 1}/${nCells.length}`, "color:#FF9800");
this.playCurrentIndex(nCells.get(nextNIndex));
} else {
const nextIndex = this._cellData.currentCellIndex + 1;
if (nextIndex >= cells.length) {
console.log("%c=====================================", "color:#4CAF50;font-size:16px");
console.log("%c==============本课程学习完成了==============", "color:#4CAF50;font-size:16px;font-weight:bold");
console.log("%c=====================================", "color:#4CAF50;font-size:16px");
return;
}
console.log(`%c切换到下一个章节: ${nextIndex + 1}/${cells.length}`, "color:#FF9800");
this._cellData.currentCellIndex = nextIndex;
this._cellData.currentNCellIndex = 0;
this.playCurrentIndex();
}
} catch (error) {
this._nextUnitPending = false;
console.error('切换下一小节失败:', error);
}
},
_clearCheckInterval() {
if (this._checkInterval) {
clearInterval(this._checkInterval);
this._checkInterval = null;
}
},
_startVideoMonitoring() {
this._clearCheckInterval();
this._guardLastTime = 0;
this._guardLastWallTs = 0;
this._guardLastResumeTs = 0;
this._checkInterval = setInterval(() => {
this._checkVideoStatus();
}, this.configs.videoCheckInterval);
},
_tryResumePlayback(reason) {
if (!this._isPlaying || this._nextUnitPending || this._currentStepTitle() !== '视频') return;
const now = Date.now();
if (now - this._guardLastResumeTs < this.configs.guardResumeCooldownMs) {
return;
}
this._guardLastResumeTs = now;
const video = this._getVideoEl();
if (!video || !this._isPlaying) return;
video.muted = true;
video.defaultMuted = true;
video.volume = 0;
console.log(`%c触发视频保活恢复(${reason})`, "color:#607D8B");
video.play().catch((e) => {
console.warn("直接恢复播放失败，尝试静音恢复:", e);
video.muted = true;
video.play().catch((err) => {
console.error("静音恢复播放失败:", err);
});
});
},
_checkVideoStatus() {
try {
if (!this._nextUnitPending && this._currentStepTitle() === '视频' && this._skipCompletedVideo()) return;
// 手动从视频切到习题时，监测到新页面后立即交给答题流程。
if (!this._nextUnitPending && (this._isChapterTest() || isReadingStep(this._currentStepTitle()))) {
this.play();
return;
}
const video = this._getVideoEl();
if (!video) return;
if (this._eventVideoEl && this._eventVideoEl !== video && !this._nextUnitPending) {
this._eventVideoEl.pause();
this.play();
return;
}
video.muted = true;
video.defaultMuted = true;
video.volume = 0;
if (video.paused && this._isPlaying) {
// 弹题出现时播放器会暂停，先当作答处理，不要盲目恢复播放。
if (this._handleVideoPopup?.()) { this._pausedSince = 0; return; }
this._pausedSince = this._pausedSince || Date.now();
const pausedFor = Date.now() - this._pausedSince;
// 画面上明明挂着题目，脚本却没认出来：别再 play/pause 死循环，停下并提示手动作答。
if (pausedFor > 8000 && popupLooking()) {
if (!this._popupHinted) {
this._popupHinted = true;
console.warn('画面上有题目，但脚本没能认出选项。请在页面上手动作答（点选项 / 确定），视频会自己继续。');
}
return;
}
if (pausedFor > 20000 && !this._popupHinted) {
this._popupHinted = true;
console.warn('视频已暂停 20 秒，但没有识别到弹题。如果画面上有题目，可在控制台执行 app.inspectPopup() 查看识别结果；手动作答后脚本会继续。');
}
console.log("%c检测到视频暂停，尝试恢复播放...", "color:#FF5722");
this._tryResumePlayback("paused");
} else if (this._isPlaying && !video.ended) {
this._pausedSince = 0;
this._popupHinted = false;
this._popupTick = (this._popupTick || 0) + 1;
if (this._popupTick % 10 === 0 && this._handleVideoPopup?.()) return;
const now = Date.now();
const current = Number(video.currentTime || 0);
if (this._guardLastWallTs === 0) {
this._guardLastWallTs = now;
this._guardLastTime = current;
} else {
const stalled = Math.abs(current - this._guardLastTime) < 0.01;
const stalledMs = now - this._guardLastWallTs;
if (stalled && stalledMs >= this.configs.guardNoProgressMs) {
if (this._handleVideoPopup?.()) {
this._guardLastWallTs = now;
this._guardLastTime = current;
return;
}
this._tryResumePlayback("no-progress");
this._guardLastWallTs = now;
this._guardLastTime = Number(video.currentTime || 0);
} else if (!stalled) {
this._guardLastWallTs = now;
this._guardLastTime = current;
}
}
}
if (video.ended && this._isPlaying) {
console.log("%c检测到视频结束，准备切换下一个...", "color:#9C27B0");
this._isPlaying = false;
this._afterVideoEnd(video);
}
} catch (e) {
console.error("视频状态检查失败:", e);
}
},
_tryTimes: 0,
_stepAdvanceTimes: 0,
_stepSwitchAt: 0,
_stepSwitchPending: false,
_delayedNextUnitTimer: null,
_guardLastTime: 0,
_guardLastWallTs: 0,
_guardLastResumeTs: 0,
_pausedSince: 0,
_popupHinted: false,
_popupTick: 0,
async play() {
try {
if (this._destroyed || this._nextUnitPending) return;
const step = this._currentStepTitle();
if (step === '视频' && this._skipCompletedVideo()) return;
if (isReadingStep(step)) {
this._isPlaying = false;
this._videoEl = null;
this._detachVideoEvents();
this._clearCheckInterval();
await this._advanceReading(step);
return;
}
if (step === '章节测验') {
this._detachVideoEvents();
this._videoEl = null;
this._isPlaying = false;
this._clearCheckInterval();
this._advanceChapterTest();
return;
}
const el = this._getVideoEl();
if (el == null) {
if (this._currentStepTitle() === '视频') {
throw new Error('视频组件尚未加载完成');
}
if (this._advanceLearningStep()) {
console.log("%c当前不在视频页，已尝试切到下一学习步骤，2秒后重试", "color:#607D8B");
setTimeout(() => {
this.play();
}, 2000);
return;
}
if (this._isChapterTest()) {
this._advanceChapterTest();
return;
}
this._isPlaying = false;
this._clearCheckInterval();
if (this.configs.autoAdvanceNoVideo) {
console.warn('%c当前小节未发现视频，按配置切换到下一小节', 'color:#FF9800');
this.nextUnit();
} else {
console.warn('%c当前小节未发现视频或可识别的学习步骤，已安全停止。确认无需完成课件后，可执行 app.nextUnit()。', 'color:#FF9800');
}
return;
}
this._isPlaying = true;
this._videoEventHandle();
try {
el.muted = true;
el.defaultMuted = true;
el.volume = 0;
await el.play();
this._tryTimes = 0;
console.log('%c视频开始播放，保持页面默认播放速度', 'color:#4CAF50');
this._startVideoMonitoring();
} catch (playError) {
console.error("视频播放失败:", playError);
this._handlePlayError(playError);
}
} catch (e) {
if (this._tryTimes >= this.configs.maxRetries) {
console.error("%c视频播放失败，已达到最大重试次数", "color:#F44336;font-weight:bold", e);
this._clearCheckInterval();
return;
}
this._tryTimes++;
console.log(`%c播放失败，${this.configs.retryInterval/1000}秒后重试 (${this._tryTimes}/${this.configs.maxRetries})`, "color:#FF9800");
setTimeout(() => {
this.play();
}, this.configs.retryInterval);
}
},
_advanceLearningStep() {
if (this._stepSwitchPending && Date.now() - this._stepSwitchAt < 4000) {
return true;
}
const currentStepTitle = this._currentStepTitle();

if (currentStepTitle === "章节测验" || currentStepTitle === "视频") {
return false;
}
const clickElement = (el, label) => {
if (!el) return false;
this._stepSwitchPending = true;
this._stepSwitchAt = Date.now();
console.log(`%c尝试点击${label}`, "color:#2196F3");
el.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
return true;
};
const videoTab = stepTabs().find((tab) => tabStepKind(tab) === '视频');
if (clickElement(videoTab?.el, "“视频”页签")) {
return true;
}
return false;
},
_currentStepTitle() {
const cardsFrame = activeCardsFrame();
const tabs = stepTabs();
try {
const tabKind = tabStepKind(activeStepTab());
if (tabKind) return tabKind;
} catch (e) { /* 页签结构变化时退回旧判断 */ }
const prevTitle = document.getElementsByClassName('prev_title')[0];
const text = prevTitle ? (prevTitle.title || prevTitle.textContent || '').trim() : '';
const catalogTitle = catalogRow()?.querySelector('.posCatalog_name')?.title?.trim();
const hasLessonTabs = document.querySelectorAll('.prev_white').length > 1;
if (!hasLessonTabs && isReadingStep(catalogTitle)) return catalogTitle;
if (cardsFrame) {
// 独立的课后习题也可能排在第 0 页，优先看当前课件里可见的模块。
const modules = Array.from(cardsFrame.contentDocument?.querySelectorAll('iframe[src*="/ananas/modules/"]') || [])
.filter((frame) => frame.getClientRects().length && frame.ownerDocument.defaultView.getComputedStyle(frame).visibility !== 'hidden');
const hasWork = modules.some((frame) => frame.src.includes('/ananas/modules/work/'));
const hasVideo = modules.some((frame) => frame.src.includes('/ananas/modules/video/'));
if (hasWork !== hasVideo) return hasWork ? '章节测验' : '视频';
}
if (/^(课后习题|章节测验)$/.test(text)) return '章节测验';
if (isReadingStep(text)) return text;
if (/^(视频学习|视频)$/.test(text)) return '视频';
if (cardsFrame && tabs.length) {
// 课件序号和页签顺序一致：按实际页签取类型，三页签的小节也不会把学习目标当成视频。
const rawNum = new URL(cardsFrame.getAttribute('src'), location.href).searchParams.get('num');
const num = /^\d+$/.test(rawNum || '') ? Number(rawNum) : -1;
if (num >= 0 && tabs[num]) {
const byNum = tabStepKind(tabs[num]);
if (byNum) return byNum;
}
}
if (cardsFrame && !tabs.length) {
const num = new URL(cardsFrame.getAttribute('src'), location.href).searchParams.get('num');
if (num === '0') return '视频';
if (num === '1') return '章节测验';
}
return '';
},
_isChapterTest() {
return this._currentStepTitle() === '章节测验';
},
_advanceChapterTest() {
if (this._chapterAdvanceTimes >= 3) {
console.error('%c章节测验页面连续跳转失败，已停止以避免页面循环。请手动处理后执行 app.run()。', 'color:#F44336;font-weight:bold');
return;
}
const nextButton = $('#prevNextFocusNext:visible, #right1:visible, .nextChapter:visible').first().get(0);
if (!nextButton) {
console.warn('%c未找到章节测验的下一步按钮，已停止。', 'color:#FF9800');
return;
}
this._chapterAdvanceTimes++;
console.log('%c检测到章节测验，尝试进入下一学习步骤', 'color:#607D8B');
nextButton.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
setTimeout(() => this.play(), 2000);
},
_bindStepNavigation() {
if (this._stepNavigationBound) {
return;
}
this._stepNavigationBound = true;
const reenterVideoMode = () => {
this._videoEl = null;
this._isPlaying = false;
this._stepSwitchPending = true;
this._stepSwitchAt = Date.now();
setTimeout(() => {
try {
this._initCellData();
} catch (e) {}
this.play();
}, 1800);
};
$(document).off('click.xuexitongPlayerV4', '.prev_white').on('click.xuexitongPlayerV4', '.prev_white', (e) => {
const text = ($(e.currentTarget).text() || "").replace(/\s+/g, "");
if (text.includes("视频") || text.includes("章节测验")) {
console.log(`%c检测到步骤切换点击：${text}，准备重新识别页面`, "color:#607D8B");
reenterVideoMode();
}
});
},
_handlePlayError(error) {
console.error("播放错误详情:", error);
const video = this._getVideoEl();
if (video) {
video.muted = true;
video.play().then(() => {
console.log("%c静音播放成功", "color:#4CAF50");
this._tryTimes = 0;
this._startVideoMonitoring();
if (this._delayedNextUnitTimer) {
clearTimeout(this._delayedNextUnitTimer);
this._delayedNextUnitTimer = null;
}
}).catch(e => {
console.error("静音播放也失败:", e);
if (this._delayedNextUnitTimer) {
clearTimeout(this._delayedNextUnitTimer);
}
this._isPlaying = false;
if (this._tryTimes >= this.configs.maxRetries) {
console.error('%c静音播放失败，已达到最大重试次数', 'color:#F44336;font-weight:bold', e);
return;
}
this._tryTimes++;
this._delayedNextUnitTimer = setTimeout(() => {
this._delayedNextUnitTimer = null;
this.play();
}, this.configs.retryInterval);
});
}
},
playCurrentIndex(nCell) {
this._nextUnitPending = false;
if (!nCell) {
const el = this._getTreeContainer();
const cells = el.children("ul").children("li");
const nCells = $(cells.get(this._cellData.currentCellIndex)).find('.posCatalog_select:not(.firstLayer)');
nCell = nCells.get(this._cellData.currentNCellIndex);
}
const $nCell = $(nCell);
const clickableSpan = $nCell.find(".posCatalog_name")[0];
if (!clickableSpan) {
console.error("%c===========找不到可点击的课程节点，播放下一个视频失败==============", "color:#F44336");
return;
}
console.log(`%c点击切换到: ${$(clickableSpan).attr('title') || '未知标题'}`, "color:#2196F3");
$(clickableSpan).click();
this._videoEl = null;
this._isPlaying = false;
console.log("%c等待视频加载...", "color:#FF9800");
setTimeout(() => {
this._initCellData();
if (this.configs.autoplay) {
this.play();
}
}, 3000);
},
_initCellData() {
const el = this._getTreeContainer();
const cells = el.children("ul").children("li");
this._cellData.cells = cells.length;
let nCellCounts = 0;
let foundCurrent = false;
cells.each((i, v) => {
const nCells = $(v).find('.posCatalog_select:not(.firstLayer)');
nCellCounts += nCells.length;
nCells.each((j, e) => {
const _el = $(e);
if (_el.hasClass("posCatalog_active")) {
this._cellData.currentCellIndex = i;
this._cellData.currentNCellIndex = j;
foundCurrent = true;
const titleSpan = _el.find('.posCatalog_name')[0];
if (titleSpan) {
this._cellData.currentVideoTitle = $(titleSpan).attr('title');
}
}
});
});
this._cellData.nCells = nCellCounts;

if (!foundCurrent && nCellCounts > 0) {
console.warn("%c未找到当前激活的视频节点，可能需要手动选择", "color:#FF9800");
}
console.log('目录当前选中：' + (rowNumber(catalogRow()) || '尚未加载'), '课程共', this._cellData.nCells, '节');
},
_getTreeContainer() {
if (!this._treeContainerEl) {
const el = $('#coursetree');
if (el.length <= 0) {
throw new Error("找不到视频列表");
}
this._treeContainerEl = el;
}
return this._treeContainerEl;
},
_getVideoEl() {
const currentCard = activeCardsFrame();
if (!currentCard) { this._videoEl = null; return null; }
const tasks = currentVideoTasks(currentCard, catalogRow());
const searchRoot = tasks.find((task) => !task.done)?.frame || currentCard;
if (this._videoEl) {
let frame = this._videoEl.ownerDocument.defaultView?.frameElement;
while (frame && frame !== searchRoot && frame.isConnected) frame = frame.ownerDocument.defaultView?.frameElement;
if (frame !== searchRoot || !this._videoEl.isConnected) this._videoEl = null;
}
if (!this._videoEl) {
try {
const findVideo = (frame, depth) => {
if (depth > 2) return null;
const frameDocument = frame.contentDocument || frame.contentWindow?.document;
if (!frameDocument) return null;
const $frameDocument = $(frameDocument);
const directVideo = $frameDocument.find('video#video_html5_api, video[id*="video_html5"]').get(0);
if (directVideo) return directVideo;
const nestedFrames = $frameDocument.find('iframe.ans-insertvideo-online, iframe[src*="video"]');
for (const nestedFrame of nestedFrames.toArray()) {
const nestedVideo = findVideo(nestedFrame, depth + 1);
if (nestedVideo) return nestedVideo;
}
return null;
};
for (const frame of [searchRoot]) {
const video = findVideo(frame, 0);
if (video) {
this._videoEl = video;
video.muted = true;
video.defaultMuted = true;
video.volume = 0;
break;
}
}
} catch (e) {
console.error("获取视频元素失败:", e);
return null;
}
}
if (!this._videoEl) return null;
return this._videoEl;
},
_videoEventHandle() {
const el = this._videoEl;
if (!el) {
console.log("videoEl未加载");
return;
}
if (this._eventVideoEl === el) return;
this._detachVideoEvents();
this._eventVideoEl = el;
this._boundVideoHandlers = {
ended: this._handleVideoEnded.bind(this),
loadedmetadata: this._handleVideoLoaded.bind(this),
play: this._handleVideoPlay.bind(this),
pause: this._handleVideoPause.bind(this),
};
el.addEventListener('ended', this._boundVideoHandlers.ended);
el.addEventListener('loadedmetadata', this._boundVideoHandlers.loadedmetadata);
el.addEventListener('play', this._boundVideoHandlers.play);
el.addEventListener('pause', this._boundVideoHandlers.pause);
},
_detachVideoEvents() {
if (!this._eventVideoEl || !this._boundVideoHandlers) return;
this._eventVideoEl.removeEventListener('ended', this._boundVideoHandlers.ended);
this._eventVideoEl.removeEventListener('loadedmetadata', this._boundVideoHandlers.loadedmetadata);
this._eventVideoEl.removeEventListener('play', this._boundVideoHandlers.play);
this._eventVideoEl.removeEventListener('pause', this._boundVideoHandlers.pause);
this._eventVideoEl = null;
this._boundVideoHandlers = null;
},
_handleVideoEnded(e) {
const title = this._cellData.currentVideoTitle;
console.warn(`%c============'${title}' 播放完成=============`, "color:#4CAF50;font-weight:bold");
this._isPlaying = false;
this._clearCheckInterval();
this._afterVideoEnd(e.currentTarget);
},
_afterVideoEnd(video) {
if (this._delayedNextUnitTimer || this._nextUnitPending || this._destroyed) return;
const card = activeCardsFrame();
const doc = card?.contentDocument;
const number = rowNumber(catalogRow());
let attempts = 0;
const advance = () => {
this._delayedNextUnitTimer = null;
if (this._destroyed || this._nextUnitPending || rowNumber(catalogRow()) !== number || activeCardsFrame()?.contentDocument !== doc) return;
if (this._skipCompletedVideo()) return;
const tasks = currentVideoTasks(card, catalogRow());
if (tasks.length <= 1) {
// 平台记录任务点完成有延迟；等几秒再判断，避免这一节还有测验却直接跳去下一节。
if (++attempts < 8 && !tasks.every((task) => task.done)) {
this._delayedNextUnitTimer = setTimeout(advance, 500);
return;
}
const tab = nextTaskPointTab();
if (tab) {
console.log('本小节还有“' + tab.bare + '”，先进入该任务点');
this.nextUnit({ button: tab.el, row: catalogRow(), quiz: true });
return;
}
this.nextUnit();
return;
}
// 多视频课件要等刚播完的这一条被平台记为完成，再播放剩下的。
if (this._getVideoEl() !== video) { this.play(); return; }
if (++attempts < 20) this._delayedNextUnitTimer = setTimeout(advance, 500);
else console.log('视频已播完，平台还未确认这个任务点。已留在当前页。');
};
this._delayedNextUnitTimer = setTimeout(advance, 1000);
},
_handleVideoLoaded(e) {
console.log(`%c============视频加载完成=============`, "color:#2196F3");
if (this.configs.autoplay && !this._isPlaying) {
this.play();
}
},
_handleVideoPlay(e) {
const title = this._cellData.currentVideoTitle;
console.info(`%c============'${title}' 开始播放=============`, "color:#4CAF50");
this._isPlaying = true;
this._stepSwitchPending = false;
const video = this._getVideoEl();
this._guardLastTime = Number(video?.currentTime || 0);
this._guardLastWallTs = Date.now();
if (this._delayedNextUnitTimer) {
clearTimeout(this._delayedNextUnitTimer);
this._delayedNextUnitTimer = null;
}
},
_handleVideoPause(e) {
console.log(`%c============视频暂停=============`, "color:#FF9800");
},
_bindPageGuards() {
const preventPause = (e) => {
e.stopPropagation();
e.preventDefault();
};
const recheckCurrentPage = () => {
if (document.hidden || this._destroyed || this._nextUnitPending) return;
const number = rowNumber(catalogRow());
if (!number) return;
if (number !== this._observedNumber) {
this._observedNumber = number;
this._initCellData();
this._detachVideoEvents();
this._clearCheckInterval();
this._videoEl = null;
this._isPlaying = false;
this.play();
} else if (isReadingStep(this._currentStepTitle())) {
this.play();
}
};
this._observedNumber = rowNumber(catalogRow());
this._onReturnToCourse = recheckCurrentPage;
window.addEventListener('focus', recheckCurrentPage);
document.addEventListener('visibilitychange', recheckCurrentPage);
this._catalogWatch = setInterval(() => {
if (rowNumber(catalogRow()) !== this._observedNumber) recheckCurrentPage();
}, 900);
const resumePlaybackNow = () => this._tryResumePlayback('page-event');
this._pageGuards = { preventPause, resumePlaybackNow };
document.addEventListener('mouseleave', preventPause);
window.addEventListener('mouseleave', preventPause);
document.addEventListener('mouseout', preventPause);
window.addEventListener('mouseout', preventPause);
window.addEventListener('blur', resumePlaybackNow);
document.addEventListener('visibilitychange', resumePlaybackNow);
},
destroy() {
this._destroyed = true;
clearInterval(this._catalogWatch);
window.removeEventListener('focus', this._onReturnToCourse);
document.removeEventListener('visibilitychange', this._onReturnToCourse);
this._isPlaying = false;
this._clearCheckInterval();
this._detachVideoEvents();
if (this._delayedNextUnitTimer) clearTimeout(this._delayedNextUnitTimer);
$(document).off('.xuexitongPlayerV4');
if (this._pageGuards) {
const { preventPause, resumePlaybackNow } = this._pageGuards;
document.removeEventListener('mouseleave', preventPause);
window.removeEventListener('mouseleave', preventPause);
document.removeEventListener('mouseout', preventPause);
window.removeEventListener('mouseout', preventPause);
window.removeEventListener('blur', resumePlaybackNow);
document.removeEventListener('visibilitychange', resumePlaybackNow);
this._pageGuards = null;
}
},
};
attachQuizAutomation(app);
PAGE.app = app;
PAGE[APP_KEY] = app;

try {
app.run();
app._bindPageGuards();
} catch (error) {
console.error("%c脚本运行失败: ", "color:#F44336;font-weight:bold", error.message);
console.log("请检查是否在正确的课程播放页面，或者页面结构是否再次发生改变。");
}
}
})();

