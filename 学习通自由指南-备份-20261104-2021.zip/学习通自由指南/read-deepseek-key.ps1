﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# 使用独立输入框，避免终端把粘贴或回车误当成空输入。
$form = New-Object System.Windows.Forms.Form
$form.Text = '输入 DeepSeek 密钥'
$form.ClientSize = New-Object System.Drawing.Size(570, 250)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)
$form.AutoScaleMode = 'Dpi'

$instructions = New-Object System.Windows.Forms.Label
$instructions.Text = '粘贴完整的 DeepSeek API Key，再点“确认”。' + [Environment]::NewLine + '输入框会隐藏密钥，只显示收到的字符数。'
$instructions.Location = New-Object System.Drawing.Point(20, 18)
$instructions.Size = New-Object System.Drawing.Size(530, 54)
$form.Controls.Add($instructions)

$keyBox = New-Object System.Windows.Forms.TextBox
$keyBox.Location = New-Object System.Drawing.Point(20, 82)
$keyBox.Size = New-Object System.Drawing.Size(410, 30)
$keyBox.UseSystemPasswordChar = $true
$keyBox.TabIndex = 0
$form.Controls.Add($keyBox)

$pasteButton = New-Object System.Windows.Forms.Button
$pasteButton.Text = '粘贴密钥'
$pasteButton.Location = New-Object System.Drawing.Point(440, 80)
$pasteButton.Size = New-Object System.Drawing.Size(110, 32)
$pasteButton.TabIndex = 1
$form.Controls.Add($pasteButton)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = '尚未收到内容。可在输入框按 Ctrl+V，或点“粘贴密钥”。'
$statusLabel.Location = New-Object System.Drawing.Point(20, 122)
$statusLabel.Size = New-Object System.Drawing.Size(530, 46)
$form.Controls.Add($statusLabel)

$privacyLabel = New-Object System.Windows.Forms.Label
$privacyLabel.Text = '密钥只在本次运行中使用，不保存到文件。'
$privacyLabel.Location = New-Object System.Drawing.Point(20, 202)
$privacyLabel.Size = New-Object System.Drawing.Size(305, 30)
$privacyLabel.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($privacyLabel)

$confirmButton = New-Object System.Windows.Forms.Button
$confirmButton.Text = '确认'
$confirmButton.Location = New-Object System.Drawing.Point(340, 192)
$confirmButton.Size = New-Object System.Drawing.Size(100, 36)
$confirmButton.TabIndex = 2
$form.Controls.Add($confirmButton)
$form.AcceptButton = $confirmButton

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Text = '取消'
$cancelButton.Location = New-Object System.Drawing.Point(450, 192)
$cancelButton.Size = New-Object System.Drawing.Size(100, 36)
$cancelButton.TabIndex = 3
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($cancelButton)
$form.CancelButton = $cancelButton

$keyBox.Add_TextChanged({
    $count = $keyBox.Text.Trim().Length
    $statusLabel.ForeColor = [System.Drawing.Color]::Black
    $statusLabel.Text = if ($count) { '已收到 {0} 个字符，点击“确认”后检查密钥。' -f $count } else { '尚未收到内容，请粘贴密钥。' }
})
$pasteButton.Add_Click({
    try {
        $keyBox.Text = [System.Windows.Forms.Clipboard]::GetText().Trim()
        [void]$keyBox.Focus()
        if (!$keyBox.Text) { $statusLabel.Text = '剪贴板没有文字，请先复制完整密钥，再点“粘贴密钥”。' }
    } catch {
        $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick
        $statusLabel.Text = '暂时无法读取剪贴板，请在输入框按 Ctrl+V。'
    }
})
$confirmButton.Add_Click({
    $candidate = $keyBox.Text.Trim()
    if (!$candidate) {
        $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick
        $statusLabel.Text = '还没有收到密钥，请先粘贴；这个窗口会继续等待。'
        [void]$keyBox.Focus()
        return
    }
    if ($candidate.Length -gt 4096 -or $candidate -notmatch '^[\x21-\x7e]+$' -or $candidate.Contains('*')) {
        $statusLabel.ForeColor = [System.Drawing.Color]::Firebrick
        $statusLabel.Text = '请复制完整密钥，不要包含中文、空格、换行或隐藏用的星号。'
        return
    }
    $form.Tag = $candidate
    $form.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.Close()
})
$form.Add_Shown({ $form.Activate(); [void]$keyBox.Focus() })

$dialogResult = $form.ShowDialog()
try {
    # 输出只通过内部管道交给本地服务，不显示在终端里。
    if ($dialogResult -eq [System.Windows.Forms.DialogResult]::OK) {
        [Console]::Write((ConvertTo-Json -Compress -InputObject @{ key = [string]$form.Tag }))
    } else {
        [Console]::Write('{"cancelled":true}')
    }
} finally {
    $keyBox.Clear()
    $form.Tag = $null
    $form.Dispose()
}
