@echo off
chcp 65001 >nul
setlocal
rem Copies this run's console script to the clipboard; nothing is printed.
pushd "%~dp0"
if errorlevel 1 exit /b 1
if not exist "copy-console-script.ps1" (
  echo Missing copy-console-script.ps1.
  echo Extract the entire ZIP before running this file.
  popd
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "copy-console-script.ps1" %*
set "RESULT=%ERRORLEVEL%"
popd
if not "%RESULT%"=="0" echo Copy failed with code %RESULT%. Read the message above.
pause
exit /b %RESULT%
