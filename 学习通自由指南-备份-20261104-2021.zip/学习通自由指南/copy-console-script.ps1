﻿param([string]$Mode = 'loader')
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

$url = 'http://127.0.0.1:37841'
# 默认只复制一行加载命令：1600 多行整份粘贴容易在途中损坏（控制台报 Invalid or unexpected token）。
$loader = "fetch('$url/script').then(r=>r.text()).then(t=>{try{eval(t)}catch(e){const s=document.createElement('script');s.src='$url/script';document.body.appendChild(s)}})"

$path = Join-Path $PSScriptRoot 'xuexitong-console.js'
if (-not (Test-Path -LiteralPath $path)) {
    Write-Host '这个文件夹里没有 xuexitong-console.js。' -ForegroundColor Red
    Write-Host '请把整个压缩包完整解压到一个文件夹，再从解压后的文件夹里双击本文件。' -ForegroundColor Red
    exit 2
}

if ($Mode -eq 'full') {
    $text = Get-Content -LiteralPath $path -Raw -Encoding UTF8
    $label = '整份网页脚本'
} else {
    $text = $loader
    $label = '一行加载命令'
}

$copied = 0
try {
    Set-Clipboard -Value $text
    Start-Sleep -Milliseconds 200
    $copied = (Get-Clipboard -Raw).Length
} catch {
    $copied = 0
}
if ($copied -ne $text.Length) {
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.Clipboard]::SetText($text)
        Start-Sleep -Milliseconds 200
        $copied = (Get-Clipboard -Raw).Length
    } catch {
        $copied = 0
    }
}
if ($copied -ne $text.Length) {
    Write-Host ('复制没有成功：剪贴板里只有 ' + $copied + ' 个字符，应为 ' + $text.Length + '。') -ForegroundColor Red
    Write-Host '请关闭占用剪贴板的程序（远程桌面、剪贴板管理器等）后重试。' -ForegroundColor Red
    exit 3
}

Write-Host ('已复制' + $label + '，共 ' + $text.Length + ' 个字符。') -ForegroundColor Green
if ($Mode -ne 'full') {
    Write-Host ''
    Write-Host '命令内容：'
    Write-Host $loader -ForegroundColor DarkGray
    Write-Host ''
}

$serviceReady = $false
try {
    $probe = Invoke-WebRequest -Uri "$url/script" -Headers @{ Origin = 'https://mooc1.chaoxing.com' } -TimeoutSec 3 -UseBasicParsing
    $serviceReady = ($probe.StatusCode -eq 200)
} catch {
    $serviceReady = $false
}
if ($serviceReady) {
    Write-Host '本地服务正在运行，可以直接粘贴到课程页。'
} else {
    Write-Host '提示：本地服务没有运行，或还是旧版本（没有 /script 接口）。请先双击 start-local-service.cmd。' -ForegroundColor Yellow
    Write-Host '      旧版本也可以整份粘贴：在文件夹空白处按住 Shift 右键 → 在此处打开 PowerShell → 执行 .\复制网页脚本.cmd full' -ForegroundColor Yellow
}
Write-Host '回到学习通课程页：按 F12 打开控制台，选择 top，粘贴后按 Enter。'
Write-Host '如果浏览器提示 allow pasting，就在控制台里手敲这几个字母再回车，然后重新粘贴。'
Write-Host '跑起来之后可以按 F12 关掉开发者工具：进度会显示在页面右下角。'
exit 0
