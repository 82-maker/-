const API_URL = 'https://api.deepseek.com/chat/completions';
const SYSTEM_PROMPT = '按题意回答全部题目。注意：题干或选项可能经过网页防复制处理，出现个别汉字被替换、插入无关字，或词语看起来不通顺。先结合上下文和选项在内部还原最可能的原句，再按还原后的题意作答；不要把明显异常的替换字当作专业术语，也不要因无法逐字还原而放弃。每题都必须给非空答案，只用该题提供的选项字母且不可重复；单选和判断选一个，多选列出所有正确项。不确定时选最可能的答案。id须对应题号。只输出JSON：{"answers":[{"id":1,"letters":["A"]}]}。';

// 现场出现过：开思考 + max_tokens 8000 时，4 道题就把输出预算吃满，答案整段被截断（finish_reason=length）。
// 输出总量有上限，光调大 max_tokens 不一定有用，所以主要靠“每次少问几道”保证答完。
// 3 道题一次是已经验证过能出完整答案的规模；题更多就分批，先保住准确率，再退到关思考、逐题。
const PLANS = [
    { label: '三题一批·低强度思考', batch: 3, settings: { thinking: { type: 'enabled' }, reasoning_effort: 'low', max_tokens: 8000 } },
    { label: '三题一批·不思考', batch: 3, settings: { thinking: { type: 'disabled' }, max_tokens: 8192 } },
    { label: '逐题回答·不思考', batch: 1, settings: { thinking: { type: 'disabled' }, max_tokens: 4096 } },
    { label: '逐题回答·低强度思考', batch: 1, settings: { thinking: { type: 'enabled' }, reasoning_effort: 'low', max_tokens: 8000 } },
];

export async function requestAnswers(questions, apiKey, fetchImpl = fetch) {
    let lastProblem = '';
    for (const [index, plan] of PLANS.entries()) {
        if (index > 0) console.warn(`${lastProblem}；改用「${plan.label}」重新请求`);
        try {
            return await runPlan(plan, questions, apiKey, fetchImpl);
        } catch (error) {
            if (error.fatal) throw error;
            lastProblem = error.message;
        }
    }
    throw new Error(`${lastProblem}；多轮重试后仍未获得完整答案，没有选择或提交题目`);
}

async function runPlan(plan, questions, apiKey, fetchImpl) {
    const size = Number.isFinite(plan.batch) ? Math.max(1, plan.batch) : questions.length;
    const batches = [];
    for (let offset = 0; offset < questions.length; offset += size) {
        batches.push(questions.slice(offset, offset + size));
    }
    if (batches.length > 1) console.log(`  这批题分 ${batches.length} 次请求（每次 ${size} 题）`);
    const answers = [];
    for (const batch of batches) {
        answers.push(...await requestBatch(batch, plan, apiKey, fetchImpl));
    }
    return answers.sort((a, b) => a.id - b.id);
}

async function requestBatch(batch, plan, apiKey, fetchImpl) {
    const body = {
        model: 'deepseek-flash',
        stream: false,
        response_format: { type: 'json_object' },
        ...plan.settings,
        messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: JSON.stringify(batch) },
        ],
    };
    const response = await fetchImpl(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(180000),
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
        const detail = data?.error?.message || data?.error || data?.message || '';
        const error = new Error(`DeepSeek API 返回 HTTP ${response.status}${detail ? `：${detail}` : ''}`);
        // 密钥无效或被封号时，换参数重试也没有意义。
        if (response.status === 401 || response.status === 402 || response.status === 403) error.fatal = true;
        throw error;
    }
    const choice = data?.choices?.[0];
    const reason = choice?.finish_reason;
    if (reason === 'length') {
        throw new Error(`输出达到长度上限（已生成 ${data.usage?.completion_tokens ?? '未知'} tokens）`);
    }
    if (reason !== 'stop') throw new Error(`DeepSeek 未正常结束（finish_reason=${reason ?? '缺失'}）`);
    let parsed;
    try {
        parsed = JSON.parse(choice?.message?.content || '');
    } catch {
        throw new Error('返回空内容或无法解析为 JSON');
    }
    const items = parsed?.answers;
    if (!Array.isArray(items) || items.length !== batch.length) {
        throw new Error('返回的题目数量不对');
    }
    const expected = new Set(batch.map((q) => q.id));
    return items.map((item) => {
        const id = item?.id;
        if (!Number.isInteger(id) || !expected.has(id) || !Array.isArray(item.letters) || !item.letters.length) {
            throw new Error(`第 ${id ?? '?'} 题的答案格式不正确`);
        }
        return { id, letters: item.letters };
    });
}
