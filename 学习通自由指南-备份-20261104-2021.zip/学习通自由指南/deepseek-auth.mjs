export async function validateApiKey(apiKey, fetchImpl = fetch) {
    let response;
    try {
        // 查询官方账户接口确认密钥，不发送题目或生成答案。
        response = await fetchImpl('https://api.deepseek.com/user/balance', {
            method: 'GET',
            headers: { Authorization: `Bearer ${apiKey}` },
            redirect: 'error',
            signal: AbortSignal.timeout(20000),
        });
    } catch {
        throw new Error('暂时连接不上 DeepSeek，尚未确认密钥是否有效。请检查网络后重新启动。');
    }
    if (response.status === 401) {
        const error = new Error('DeepSeek 没有认可这串密钥（401）。请在官方平台重新复制完整 API Key。');
        error.code = 'INVALID_API_KEY';
        throw error;
    }
    if (!response.ok) {
        throw new Error(`DeepSeek 暂时无法完成检查（HTTP ${response.status}），服务没有启动，请稍后重试。`);
    }
    const data = await response.json().catch(() => null);
    if (typeof data?.is_available !== 'boolean') {
        throw new Error('DeepSeek 返回的检查结果不完整，服务没有启动，请稍后重试。');
    }
    return { available: data.is_available };
}
