import { execFile } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { existsSync } from 'node:fs';

// 只有这个错误码表示“图形窗口这条路走不通”，调用方可以据此改用控制台输入。
// 用户主动取消、窗口没有返回内容时窗口本身是正常的，不应回退到明文输入。
const UNAVAILABLE = 'KEY_WINDOW_UNAVAILABLE';

function unavailable(message) {
    const error = new Error(message);
    error.code = UNAVAILABLE;
    return error;
}

function findPowerShell() {
    // 依次尝试：本机运行时自带的 pwsh 7、已安装的 PowerShell 7、系统自带的 Windows PowerShell 5.1。
    return [
        join(process.env.USERPROFILE || '', '.cache', 'codex-runtimes', 'codex-primary-runtime', 'dependencies', 'native', 'powershell', 'pwsh.exe'),
        join(process.env.ProgramFiles || 'C:\\Program Files', 'PowerShell', '7', 'pwsh.exe'),
        join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
    ].find((path) => existsSync(path));
}

export function readWindowsApiKey() {
    const scriptPath = fileURLToPath(new URL('./read-deepseek-key.ps1', import.meta.url));
    const executable = findPowerShell();
    return new Promise((resolve, reject) => {
        if (!executable) {
            reject(unavailable('这台电脑上没找到 PowerShell，无法打开密钥输入窗口。'));
            return;
        }
        if (!existsSync(scriptPath)) {
            reject(unavailable('同一文件夹里缺少 read-deepseek-key.ps1，请把整个压缩包完整解压后再运行。'));
            return;
        }
        // -ExecutionPolicy Bypass 只作用于这个子进程，不会改动电脑上的任何执行策略设置。
        // 系统默认的 Restricted 策略会拒绝 -File，文件带有“来自网络”标记时 RemoteSigned 也会拒绝，所以必须带上它。
        execFile(executable, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', scriptPath], {
            // 这个进程负责显示输入框，隐藏它会导致桌面上只能看到黑色窗口。
            windowsHide: false,
            encoding: 'utf8',
            maxBuffer: 32768,
        }, (error, stdout, stderr) => {
            if (error) {
                const detail = String(stderr || '').replace(/\s+/g, ' ').trim().slice(0, 240);
                reject(unavailable(detail
                    ? `PowerShell 没能打开密钥输入窗口：${detail}`
                    : `PowerShell 没能打开密钥输入窗口（退出码 ${error.code ?? '未知'}）。`));
                return;
            }
            try {
                const result = JSON.parse(stdout.trim().replace(/^\uFEFF/, ''));
                if (result.cancelled) {
                    reject(new Error('已取消输入，服务没有启动。'));
                } else if (typeof result.key === 'string' && result.key.trim()) {
                    resolve(result.key.trim());
                } else {
                    reject(unavailable('输入窗口没有返回密钥。'));
                }
            } catch {
                // 不输出原始结果，避免错误消息带出密钥。
                reject(unavailable('无法读取输入窗口的结果。'));
            }
        });
    });
}
